from PIL import Image
import numpy as np
import json

def trans(img_path):
    src = Image.open(img_path + ".png")
    src_w, src_h = src.size
    w = src_w // 16
    h = src_h // 16
    img_array = np.array(src)
    for i in range(w * h):
        row = i // w
        col = i % w
        x = col * 16
        y = row * 16
        block = img_array[y:y+16, x:x+16]
        cropped = block[:13, :13]
        pixels = cropped.tolist()

        with open(f"chc/basic/{img_path}/{row}_{col}.json", "w") as f:
            json.dump(pixels, f)

trans("model") # 将 model.png 转化为chc信息源

print("done.")