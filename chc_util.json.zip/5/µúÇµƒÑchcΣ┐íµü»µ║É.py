import re
import json
from PIL import Image
import numpy as np

def print_help():
    print("""[help]
    输入指令以执行。
    输入“.”以退出。
    show [key] : 显示图形
    """)

class View_chc:
    def __init__(self, namespace):
        with open(namespace + ".json", "r") as f:
            self.data = json.load(f)
        
    def show_image(self, key):
        with open(self.data[key], "r") as f:
            pixels = json.load(f)  
        img_array = np.array(pixels, dtype=np.uint8)  
        img = Image.fromarray(img_array, mode="RGBA")
        background = Image.new("RGBA", img.size, (255, 255, 255, 255))
        background.paste(img, (0, 0), img)
        background = background.resize((background.width * 16, background.height * 16), Image.NEAREST)
        background = background.convert("RGB")
        background.show()

view = View_chc("chc_basic")

def p(cmd):
    if cmd == ".":
        return False
    elif s := re.match(r"show (\S+)", cmd):
        key = s.group(1)
        view.show_image(key)
    else:
        print_help()
    return True

def r():
    while True:
        cmd = input("_ ")
        if not p(cmd):
            break

p("show blank_cube") # 这是一个示例输入，在控制台展示 blank_cube 的图形
r()